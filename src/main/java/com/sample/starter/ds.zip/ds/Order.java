package com.sample.starter.ds;

import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import lombok.AllArgsConstructor;

@Entity
@AllArgsConstructor
public class Order{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private String orderId;
    private String customerId;
    private String vendorId;
    private String localDate;
    private String serviceType;
    private Integer amount;
    // public boolean PaymentGateway();
    // public boolean GenerateReceipt();
}