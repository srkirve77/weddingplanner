package com.sample.starter.ds;




import lombok.NoArgsConstructor;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import lombok.AllArgsConstructor;

@Entity
@AllArgsConstructor
public class Vendor{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private String vendorId;
    private String username;
    private String contact;
    private boolean loggedIn;
    // public void SignUp(Vendor vendor);
    // public void SignIn(Vendor vendor);
    // public void SignOut(Vendor vendor);
    // public void UpdateInfo(Vendor vendor);

}