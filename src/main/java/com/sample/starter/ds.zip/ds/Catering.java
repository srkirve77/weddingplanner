package com.sample.starter.ds;

import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@AllArgsConstructor
@Entity
public class Catering{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private String cateringId;
    private String vendorId;
    private Integer capacity;
    private String location;
    //public void CateringRegistration(Catering catering);
    
}